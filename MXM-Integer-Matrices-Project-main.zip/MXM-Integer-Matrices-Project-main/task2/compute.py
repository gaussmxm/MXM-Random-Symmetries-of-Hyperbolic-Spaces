import sys

def print_results(num, num_loxodromic, radius):
    print("N(" + str(radius) + ") = " + str(num))
    print("L(" + str(radius) + ") = " + str(num_loxodromic))
    print("L(" + str(radius) + ")/N(" + str(radius) + ") = %.3f" % (num_loxodromic / num))

a = (0, -1, 1, 0)
b = (1, 1, 0, 1)

a_inv = (a[3], -a[1], -a[2], a[0])
b_inv = (b[3], -b[1], -b[2], b[0])

generators = [a, a_inv, b, b_inv, (1, 0, 0, 1)]

if len(sys.argv) != 2:
    print("Usage: " + sys.argv[0] + " [DISTANCE]")
    sys.exit(1)

radius = 0

try:
    radius = int(sys.argv[1])
except:
    print("Error: invalid distance")
    sys.exit(1)

if radius < 1:
    print("Error: distance not >= 1")
    sys.exit(1)

matrices = set(generators)
num = len(matrices)
num_loxodromic = 0

for i in range(1, radius):
    print_results(num, num_loxodromic, i)
    print()

    tmp_matrices = set()

    for n in matrices:
        for m in generators:
            tmp = (m[0] * n[0] + m[1] * n[2],
                   m[0] * n[1] + m[1] * n[3],
                   m[2] * n[0] + m[3] * n[2],
                   m[2] * n[1] + m[3] * n[3])

            if tmp not in matrices and tmp not in tmp_matrices:
                num += 1
                tmp_matrices.add(tmp)

                if ((tmp[0] + tmp[3]) ** 2) > 4:
                    num_loxodromic += 1

    matrices = matrices.union(tmp_matrices)

print_results(num, num_loxodromic, radius)
