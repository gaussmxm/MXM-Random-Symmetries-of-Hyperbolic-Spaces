# Takes an element of PSL(2,Z) and converts into a word composed of S and T.
# All it does at the moment is reduce exponents mod 2 and 3, combine like
# adjacent terms, and remove identities. All exponents are positive.

import copy
import sys

def convert_to_word(M):
    result = []

    if M[0] != 0 and M[1] != 0:
        if M[0] < 0:
            M[0] *= -1
            M[1] *= -1
            M[2] *= -1
            M[3] *= -1

        if M[1] < 0:
            k = 1
            
            while k * M[0] <= -M[1]:
                ++k
            
            M[1] += k * M[0]
            M[3] += k * M[2]

            for i in range(k):
                result += [['S', 1], ['T', 1]]

        while M[0] != 0 and M[1] != 0:
            if M[0] >= M[1]:
                k = M[0] // M[1]

                M[0] = M[0] % M[1]
                M[2] -= k * M[3]

                for i in range(k):
                    result = [['T', 1], ['S', 1]] + result

            else:
                k = M[1] // M[0]

                M[1] = M[1] % M[0]
                M[3] -= k * M[2]

                for i in range(k):
                    result = [['T', 2], ['S', 1]] + result

    if M[0] == 0:
        
        if -M[3] >= 0:   
            for i in range(-M[3]):
                result = [['T', 2], ['S', 1]] + result

        else:
            for i in range(M[3]):
                result = [['S', 1], ['T', 1]] + result

        result = [['S', 1]] + result

    if M[1] == 0:

        if -M[2] >= 0:
            for i in range(-M[2]):
                result = [['S', 1], ['T', 2]] + result

        else:
            for i in range(M[2]):
                result = [['T', 1], ['S', 1]] + result

    while True:
        prev = copy.deepcopy(result)

        for i in range(len(result)):
            if result[i][1] == 0:
                result.pop(i)
                break

            if i != len(result) - 1 and result[i + 1][0] == result[i][0]:
                result[i][1] += result[i + 1][1]
                result.pop(i + 1)
                break
            
            if result[i][0] == 'S':
                result[i][1] %= 2

            if result[i][0] == 'T':
                result[i][1] %= 3

        if prev == result:
            break

    return result

def usage():
    print("usage: %s a1 a2 a3 a4" % (sys.argv[0]))
    print("a1, a2, a3, and a4 are integers such that [a1, a2, a3, a4] is in SL(2,Z).")
    exit()

if len(sys.argv) != 5:
    print("error: incorrect number of arguments.")
    usage()

M = [0, 0, 0, 0]

for i in range(4):
    try:
        M[i] = int(sys.argv[i + 1]) 
    except:
        print("error: one of the provided matrix entries was not parseable.")
        usage()

if (M[0] * M[3]) - (M[1] * M[2]) != 1:
    print("error: provided matrix is not invertible.")
    usage()
    exit()

print(convert_to_word(M))
