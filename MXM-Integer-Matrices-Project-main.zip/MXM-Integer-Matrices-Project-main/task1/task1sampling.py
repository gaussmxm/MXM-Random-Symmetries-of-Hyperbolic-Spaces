import sys
import random

# This is a script that performs a specified number of non-backtracking random walks 
# using a given generating set and a given probability distribution. It computes the
# number of walks which ended with a loxodromic matrix and uses that number to estimate
# the probability that a random walk with the given parameters results in a loxodromic
# matrix.

# These two lists represent the generating set
a = (0, -1, 1, 0)
b = (1, 1, 0, 1)

a_inv = (a[3], -a[1], -a[2], a[0])
b_inv = (b[3], -b[1], -b[2], b[0])

generators = [a, a_inv, b, b_inv]

# This is the specified probability distribution. The nth entry is the probability of
# choosing the nth entry in the above list of generators
prob = [0.25, 0.25, 0.25, 0.25]

# Here we precompute all of the probability distributions that will be used for sampling
# probabilities[i] contains the distribution to be used when the ith generator should
# not be chosen
probabilities = []
for i in range(4):
    s = 1 - prob[i]
    new_prob = [prob[0]/s, prob[1]/s, prob[2]/s, prob[3]/s]
    new_prob[i] = 0
    probabilities.append(new_prob)



if prob[0] + prob[1] + prob[2] + prob[3] != 1.0:
    print("Error: probabilities don't add up to 1")
    sys.exit(1)

if len(sys.argv) != 3:
    print("Usage: " + sys.argv[0] + " [LENGTH] [ITERATIONS]")
    sys.exit(1)

length = 0

try:
    length = int(sys.argv[1])
except:
    print("Error: invalid length")
    sys.exit(1)

try:
    n = int(sys.argv[2])
except:
    print("Error: invalid number of iterations")
    sys.exit(1)

num_lox = 0
for i in range(n):
    # Randomly sample from the full distribution to choose the
    # starting matrix
    rand = random.random()
    if rand < prob[0]:
        index = 0
    elif rand < prob[0] + prob[1]:
        index = 1
    elif rand < prob[0] + prob[1] + prob[2]:
        index = 2
    else:
        index = 3

    matrix = generators[index]
    #iterate length-1 times to compute the rest of the random walk
    for j in range(length-1):
        # Compute the index of the previously chosen matrix's inverse
        if index % 2 == 0:
            remove_index = index + 1
        else:
            remove_index = index - 1

        # Choose the next matrix according to the distribution that 
        # excludes the previously chosen matrix's inverse
        rand = random.random()
        if rand < probabilities[remove_index][0]:
            index = 0
        elif rand < (probabilities[remove_index][0] + probabilities[remove_index][1]):
            index = 1
        elif rand < (probabilities[remove_index][0] + probabilities[remove_index][1] + probabilities[remove_index][2]):
            index = 2
        else:
            index = 3
        
        # Left multiply the current matrix by the chosen matrix 
        matrix = (generators[index][0] * matrix[0] + generators[index][1] * matrix[2],
                   generators[index][0] * matrix[1] + generators[index][1] * matrix[3],
                   generators[index][2] * matrix[0] + generators[index][3] * matrix[2],
                   generators[index][2] * matrix[1] + generators[index][3] * matrix[3])
    # After each random walk check if the resulting matrix is loxodromic
    # increment a counter variable if it is
    if (matrix[0] + matrix[3]) ** 2 > 4:
        num_lox = num_lox + 1

# After all n walks have been computed, display output
print("Random walk length = " + str(length))
print("Number of random walks = " + str(n))
print("Number of Loxodromic Matrices = " + str(num_lox))
print("Experimental probability = " + str(num_lox / n))




