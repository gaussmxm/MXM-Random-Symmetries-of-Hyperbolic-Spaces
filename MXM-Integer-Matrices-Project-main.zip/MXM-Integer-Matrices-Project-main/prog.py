# Input: Element of SL(2,Z).
# Output: Representation of the element in terms of s = (0, 1, -1, 0) and t = (0, 1, -1, 1), up
# to sign, since we are technically inside of PSL(2,Z) here.

import sys

def usage():
    print("usage: %s a1 a2 a3 a4" % (sys.argv[0]))
    print("a1, a2, a3, and a4 are integers such that [a1, a2, a3, a4] is in SL(2,Z).")
    exit()

if len(sys.argv) != 5:
    print("error: incorrect number of arguments.")
    usage()

M = [0, 0, 0, 0]

for i in range(4):
    try:
        M[i] = int(sys.argv[i + 1]) 
    except:
        print("error: one of the provided matrix entries was not parseable.")
        usage()

if (M[0] * M[3]) - (M[1] * M[2]) != 1:
    print("error: provided matrix is not invertible.")
    usage()
    exit()

result = ""

if M[0] != 0 and M[1] != 0:
    if M[0] < 0:
        M[0] *= -1
        M[1] *= -1
        M[2] *= -1
        M[3] *= -1

    if M[1] < 0:
        k = -M[1] // M[0]
        
        M[1] += k * M[0]
        M[3] += k * M[2]

        result = "(t^(-1)s)^(-" + str(k) + ")"

    while M[0] != 0 and M[1] != 0:
        if M[0] >= M[1]:
            k = M[0] // M[1]

            M[0] = M[0] % M[1]

            M[2] -= k * M[3]

            result = "(st^(-1))^(-" + str(k) + ")" + result

        else:
            k = M[1] // M[0]

            M[1] = M[1] % M[0]

            M[3] -= k * M[2]

            result = "(st)^(-" + str(k) + ")" + result

if M[0] == 0:
    result = "s^(-1)(t^(-1)s)^(" + str(-M[3]) + ")" + result

if M[1] == 0:
    result = "(st^(-1))^(" + str(-M[2]) + ")" + result

print(result)
